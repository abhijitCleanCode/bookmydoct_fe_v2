export default function AdminDashboard() {
    return (
        <div >
            <h1 className="text-center text-3xl font-bold">Super Admin Panel!!</h1>
        </div>
    )
}
